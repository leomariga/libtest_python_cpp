#ifndef __TEST__H
#define __TEST__H
#include <iostream>


extern "C" {

int My_Function(int a);

}
#endif